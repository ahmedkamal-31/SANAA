# Sanaa - Web Prototype (Next.js)

Arabic RTL Next.js prototype with a minimal local API (file-based db.json).
This is a demo prototype for testing and quick deployment on Vercel.

## Run locally

1. Install dependencies:
